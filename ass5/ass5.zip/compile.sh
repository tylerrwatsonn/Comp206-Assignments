gcc -o database database.c
