#Tyler Watson 260867260

gcc -o triangles triangles.c		#command to compile triangles.c
