#Tyler Watson 260867260
#!/bin/bash
  
#compile reverse
gcc -o reverse reverse.c

#compile matrix
gcc -o matrix matrix.c


