//Tyler Watson 260867260

#include <stdlib.h>
#include <stdio.h>

void parse(char record[], int *acct, float *amnt) {
	sscanf(record, "%d %f", acct, amnt); //store values into acct and amnt to use in main.c
}

