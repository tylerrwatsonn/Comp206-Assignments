//Tyler Watson 260867260

#ifndef LINKEDH
#define LINKEDH

void findUpdate(int account, int amount);
void prettyPrint();

#endif
