//Tyler Watson 260867260
#ifndef SSVH
#define SSVH

void parse(char record[], int *acct, float *amnt);

#endif
